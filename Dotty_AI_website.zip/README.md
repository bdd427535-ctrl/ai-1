# Dotty AI

Black minimalist AI interface with a red Dotty dot, player data glopes, exactly five random output shapes, and persistent answer text that clears when the player types again.

Render build: `pip install -r requirements.txt`
Render start: `gunicorn server:app`
Required environment variable: `OPENAI_API_KEY`
