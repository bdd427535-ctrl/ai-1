# AI (1) — Red Dot Website

A minimal AI chat website: white screen, red center dot, bottom text box, and
AI replies that drift outward from the dot.

## Run it

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install dependencies:

   pip install -r requirements.txt

4. Set your OpenAI API key.

   macOS/Linux:
   export OPENAI_API_KEY="your_key_here"

   Windows PowerShell:
   $env:OPENAI_API_KEY="your_key_here"

5. Start the server:

   python server.py

6. Open http://127.0.0.1:5000

The API key stays on the server and is NOT placed in the browser code.

If the model name in your API account differs, set OPENAI_MODEL to a model
available to your account.
